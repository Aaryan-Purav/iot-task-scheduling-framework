#!/usr/bin/env python3
"""
Visualization script for IoT Scheduling Framework Results
Generates publication-quality plots for research presentation
"""

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

# Set publication-quality style
plt.style.use('seaborn-v0_8-paper')
sns.set_palette("husl")
plt.rcParams['figure.dpi'] = 300
plt.rcParams['savefig.dpi'] = 300
plt.rcParams['font.size'] = 10
plt.rcParams['axes.labelsize'] = 11
plt.rcParams['axes.titlesize'] = 12
plt.rcParams['legend.fontsize'] = 9

def load_data(filename='scheduling_results.csv'):
    """Load scheduling results from CSV"""
    # Read summary metrics
    df = pd.read_csv(filename, comment='#', nrows=11)
    return df

def plot_performance_comparison(df):
    """Plot 1: Performance metrics comparison"""
    fig, axes = plt.subplots(2, 2, figsize=(12, 10))
    fig.suptitle('Performance Metrics Comparison - All Scheduling Algorithms', 
                 fontsize=14, fontweight='bold')
    
    algorithms = df['Algorithm'].values
    
    # Average Waiting Time
    axes[0, 0].barh(algorithms, df['AvgWT'], color='steelblue')
    axes[0, 0].set_xlabel('Average Waiting Time (time units)')
    axes[0, 0].set_title('(a) Average Waiting Time')
    axes[0, 0].invert_yaxis()
    
    # Average Turnaround Time
    axes[0, 1].barh(algorithms, df['AvgTAT'], color='coral')
    axes[0, 1].set_xlabel('Average Turnaround Time (time units)')
    axes[0, 1].set_title('(b) Average Turnaround Time')
    axes[0, 1].invert_yaxis()
    
    # Average Response Time
    axes[1, 0].barh(algorithms, df['AvgRT'], color='mediumseagreen')
    axes[1, 0].set_xlabel('Average Response Time (time units)')
    axes[1, 0].set_title('(c) Average Response Time')
    axes[1, 0].invert_yaxis()
    
    # CPU Utilization
    axes[1, 1].barh(algorithms, df['CPUUtil'], color='mediumpurple')
    axes[1, 1].set_xlabel('CPU Utilization (%)')
    axes[1, 1].set_title('(d) CPU Utilization')
    axes[1, 1].set_xlim([95, 100])
    axes[1, 1].invert_yaxis()
    
    plt.tight_layout()
    plt.savefig('fig1_performance_comparison.png', bbox_inches='tight')
    print("✓ Generated: fig1_performance_comparison.png")

def plot_energy_analysis(df):
    """Plot 2: Energy consumption analysis"""
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    fig.suptitle('Energy Consumption and Efficiency Analysis', 
                 fontsize=14, fontweight='bold')
    
    algorithms = df['Algorithm'].values
    
    # Total Energy
    axes[0].barh(algorithms, df['TotalEnergy'], color='#FF6B6B')
    axes[0].set_xlabel('Total Energy (mJ)')
    axes[0].set_title('(a) Total Energy Consumption')
    axes[0].invert_yaxis()
    
    # Energy per Task
    axes[1].barh(algorithms, df['EnergyPerTask'], color='#4ECDC4')
    axes[1].set_xlabel('Energy per Task (mJ)')
    axes[1].set_title('(b) Energy Efficiency')
    axes[1].invert_yaxis()
    
    # Context Switches
    axes[2].barh(algorithms, df['CtxSwitch'], color='#95E1D3')
    axes[2].set_xlabel('Context Switches (count)')
    axes[2].set_title('(c) Context Switch Overhead')
    axes[2].invert_yaxis()
    
    plt.tight_layout()
    plt.savefig('fig2_energy_analysis.png', bbox_inches='tight')
    print("✓ Generated: fig2_energy_analysis.png")

def plot_performance_vs_energy(df):
    """Plot 3: Performance-Energy Trade-off"""
    fig, ax = plt.subplots(figsize=(10, 7))
    
    # Scatter plot: Avg Waiting Time vs Total Energy
    scatter = ax.scatter(df['AvgWT'], df['TotalEnergy'], 
                        s=200, alpha=0.6, c=df['AvgRT'], 
                        cmap='viridis', edgecolors='black', linewidth=1.5)
    
    # Annotate points
    for idx, row in df.iterrows():
        ax.annotate(row['Algorithm'], 
                   (row['AvgWT'], row['TotalEnergy']),
                   xytext=(5, 5), textcoords='offset points',
                   fontsize=8, alpha=0.8)
    
    ax.set_xlabel('Average Waiting Time (time units)', fontsize=12)
    ax.set_ylabel('Total Energy Consumption (mJ)', fontsize=12)
    ax.set_title('Performance vs Energy Trade-off\n(Color = Response Time)', 
                fontsize=14, fontweight='bold')
    ax.grid(True, alpha=0.3)
    
    cbar = plt.colorbar(scatter, ax=ax)
    cbar.set_label('Avg Response Time', rotation=270, labelpad=20)
    
    # Pareto front identification
    pareto = []
    for i, row_i in df.iterrows():
        dominated = False
        for j, row_j in df.iterrows():
            if i != j and row_j['AvgWT'] <= row_i['AvgWT'] and \
               row_j['TotalEnergy'] <= row_i['TotalEnergy'] and \
               (row_j['AvgWT'] < row_i['AvgWT'] or row_j['TotalEnergy'] < row_i['TotalEnergy']):
                dominated = True
                break
        if not dominated:
            pareto.append(i)
    
    if len(pareto) > 1:
        pareto_df = df.iloc[pareto].sort_values('AvgWT')
        ax.plot(pareto_df['AvgWT'], pareto_df['TotalEnergy'], 
               'r--', linewidth=2, alpha=0.5, label='Pareto Front')
        ax.legend()
    
    plt.tight_layout()
    plt.savefig('fig3_performance_energy_tradeoff.png', bbox_inches='tight')
    print("✓ Generated: fig3_performance_energy_tradeoff.png")

def plot_realtime_analysis(df):
    """Plot 4: Real-time performance"""
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    fig.suptitle('Real-Time Scheduling Performance', 
                 fontsize=14, fontweight='bold')
    
    algorithms = df['Algorithm'].values
    
    # Deadlines Missed
    colors = ['green' if x == df['DeadlinesMissed'].min() else 'red' 
             for x in df['DeadlinesMissed']]
    axes[0].barh(algorithms, df['DeadlinesMissed'], color=colors, alpha=0.7)
    axes[0].set_xlabel('Deadlines Missed (count)')
    axes[0].set_title('(a) Deadline Miss Count')
    axes[0].invert_yaxis()
    
    # Miss Rate
    axes[1].barh(algorithms, df['MissRate'], color=colors, alpha=0.7)
    axes[1].set_xlabel('Deadline Miss Rate (%)')
    axes[1].set_title('(b) Deadline Miss Rate')
    axes[1].invert_yaxis()
    
    plt.tight_layout()
    plt.savefig('fig4_realtime_analysis.png', bbox_inches='tight')
    print("✓ Generated: fig4_realtime_analysis.png")

def plot_queue_stability(df):
    """Plot 5: System stability and queue analysis"""
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    fig.suptitle('System Stability and Queue Behavior Analysis', 
                 fontsize=14, fontweight='bold')
    
    algorithms = df['Algorithm'].values
    
    # Average Queue Length
    axes[0].barh(algorithms, df['AvgQueue'], color='skyblue')
    axes[0].set_xlabel('Average Queue Length')
    axes[0].set_title('(a) Average Queue Length')
    axes[0].invert_yaxis()
    
    # Max Queue Length
    axes[1].barh(algorithms, df['MaxQueue'], color='lightcoral')
    axes[1].set_xlabel('Maximum Queue Length')
    axes[1].set_title('(b) Peak Queue Length')
    axes[1].invert_yaxis()
    
    # Queue Variance
    axes[2].barh(algorithms, df['QueueVar'], color='lightgreen')
    axes[2].set_xlabel('Queue Variance')
    axes[2].set_title('(c) Queue Stability (Lower = Better)')
    axes[2].invert_yaxis()
    
    plt.tight_layout()
    plt.savefig('fig5_queue_stability.png', bbox_inches='tight')
    print("✓ Generated: fig5_queue_stability.png")

def plot_radar_comparison(df):
    """Plot 6: Radar chart for multi-metric comparison"""
    # Select top 5 algorithms for clarity
    top_algos = ['SRTF', 'MLFQ', 'EDF', 'Hybrid Adaptive', 'Round Robin']
    df_subset = df[df['Algorithm'].isin(top_algos)].copy()
    
    # Normalize metrics (lower is better, so invert)
    metrics = ['AvgWT', 'AvgTAT', 'AvgRT', 'TotalEnergy', 'MissRate']
    df_norm = df_subset.copy()
    for metric in metrics:
        max_val = df[metric].max()
        df_norm[metric] = 1 - (df_subset[metric] / max_val)
    
    # Set up radar chart
    categories = ['Waiting Time', 'Turnaround Time', 'Response Time', 
                 'Energy Eff.', 'Deadline Perf.']
    N = len(categories)
    
    angles = [n / float(N) * 2 * np.pi for n in range(N)]
    angles += angles[:1]
    
    fig, ax = plt.subplots(figsize=(10, 10), subplot_kw=dict(projection='polar'))
    
    colors = plt.cm.Set2(np.linspace(0, 1, len(df_subset)))
    
    for idx, (_, row) in enumerate(df_norm.iterrows()):
        values = [row['AvgWT'], row['AvgTAT'], row['AvgRT'], 
                 row['TotalEnergy'], row['MissRate']]
        values += values[:1]
        
        ax.plot(angles, values, 'o-', linewidth=2, 
               label=row['Algorithm'], color=colors[idx])
        ax.fill(angles, values, alpha=0.15, color=colors[idx])
    
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(categories, size=11)
    ax.set_ylim(0, 1)
    ax.set_yticks([0.2, 0.4, 0.6, 0.8, 1.0])
    ax.set_yticklabels(['20%', '40%', '60%', '80%', '100%'])
    ax.grid(True)
    
    plt.legend(loc='upper right', bbox_to_anchor=(1.3, 1.1))
    plt.title('Multi-Metric Performance Comparison\n(Normalized Scores - Higher is Better)', 
             size=14, fontweight='bold', pad=20)
    
    plt.tight_layout()
    plt.savefig('fig6_radar_comparison.png', bbox_inches='tight')
    print("✓ Generated: fig6_radar_comparison.png")

def generate_summary_table(df):
    """Generate LaTeX table for paper"""
    with open('results_table.tex', 'w') as f:
        f.write("\\begin{table}[htbp]\n")
        f.write("\\centering\n")
        f.write("\\caption{Performance and Energy Comparison of Scheduling Algorithms}\n")
        f.write("\\label{tab:results}\n")
        f.write("\\begin{tabular}{lcccccc}\n")
        f.write("\\toprule\n")
        f.write("Algorithm & Avg WT & Avg RT & Energy & Miss Rate & Queue Var \\\\\n")
        f.write("\\midrule\n")
        
        for _, row in df.iterrows():
            f.write(f"{row['Algorithm']} & {row['AvgWT']:.1f} & {row['AvgRT']:.1f} & "
                   f"{row['TotalEnergy']:.0f} & {row['MissRate']:.1f}\\% & "
                   f"{row['QueueVar']:.1f} \\\\\n")
        
        f.write("\\bottomrule\n")
        f.write("\\end{tabular}\n")
        f.write("\\end{table}\n")
    
    print("✓ Generated: results_table.tex (LaTeX table for paper)")

def main():
    print("IoT Scheduling Framework - Result Visualization")
    print("=" * 60)
    
    # Load data
    df = load_data()
    print(f"\nLoaded data for {len(df)} algorithms\n")
    
    # Generate all plots
    plot_performance_comparison(df)
    plot_energy_analysis(df)
    plot_performance_vs_energy(df)
    plot_realtime_analysis(df)
    plot_queue_stability(df)
    plot_radar_comparison(df)
    
    # Generate LaTeX table
    generate_summary_table(df)
    
    print("\n" + "=" * 60)
    print("All visualizations generated successfully!")
    print("\nGenerated files:")
    print("  - fig1_performance_comparison.png")
    print("  - fig2_energy_analysis.png")
    print("  - fig3_performance_energy_tradeoff.png")
    print("  - fig4_realtime_analysis.png")
    print("  - fig5_queue_stability.png")
    print("  - fig6_radar_comparison.png")
    print("  - results_table.tex")
    
if __name__ == "__main__":
    main()